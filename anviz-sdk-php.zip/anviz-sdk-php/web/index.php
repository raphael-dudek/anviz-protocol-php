<?php
/**
 * Web Dashboard für Anviz SDK
 * 
 * Einfaches Web-Interface zum Steuern des Geräts
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Anviz\SDK\Core\AnvizClient;

$host = $_ENV['ANVIZ_HOST'] ?? '192.168.1.100';
$port = (int)($_ENV['ANVIZ_PORT'] ?? 5010);
$deviceId = (int)($_ENV['ANVIZ_DEVICE_ID'] ?? 1);

$action = $_GET['action'] ?? 'info';
$result = null;
$error = null;

try {
    $client = new AnvizClient($host, $port, $deviceId);
    $client->connect();

    switch ($action) {
        case 'info':
            $info = $client->getDeviceInfo();
            $result = [
                'model' => $client->getDeviceModel(),
                'firmware' => $info->getFirmwareVersion(),
                'serial' => $info->getSerialNumber(),
                'users' => $info->getUserCapacity(),
                'records' => $info->getRecordCapacity()
            ];
            break;

        case 'records':
            $recordInfo = $client->getRecordInfo();
            $records = $client->downloadRecords(10); // Letzte 10
            $result = [
                'total' => $recordInfo['totalRecords'],
                'new' => $recordInfo['newRecords'],
                'records' => array_map(function($r) {
                    return [
                        'user' => $r->getUserId(),
                        'time' => $r->getTimestamp()->format('Y-m-d H:i:s'),
                        'method' => $r->getVerificationMethod()
                    ];
                }, $records)
            ];
            break;
    }

    $client->disconnect();

} catch (Exception $e) {
    $error = $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anviz SDK Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        header { background: #2c3e50; color: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        nav { margin-bottom: 20px; }
        nav a { display: inline-block; margin-right: 10px; padding: 10px 15px; background: #3498db; color: white; text-decoration: none; border-radius: 3px; }
        nav a:hover { background: #2980b9; }
        .card { background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .card h2 { margin-bottom: 15px; color: #2c3e50; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #ecf0f1; font-weight: bold; }
        .error { background: #e74c3c; color: white; padding: 15px; border-radius: 3px; margin-bottom: 20px; }
        .success { background: #27ae60; color: white; padding: 15px; border-radius: 3px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Anviz SDK Dashboard</h1>
            <p>Gerät: <?php echo $host; ?>:<?php echo $port; ?></p>
        </header>

        <?php if ($error): ?>
            <div class="error">Fehler: <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <nav>
            <a href="?action=info" <?php echo $action === 'info' ? 'style="background: #2980b9;"' : ''; ?>>Geräteinformation</a>
            <a href="?action=records" <?php echo $action === 'records' ? 'style="background: #2980b9;"' : ''; ?>>Aufzeichnungen</a>
        </nav>

        <?php if ($result): ?>
            <div class="card">
                <?php if ($action === 'info'): ?>
                    <h2>Geräteinformationen</h2>
                    <table>
                        <tr><th>Eigenschaft</th><th>Wert</th></tr>
                        <tr><td>Modell</td><td><?php echo htmlspecialchars($result['model']); ?></td></tr>
                        <tr><td>Firmware</td><td><?php echo htmlspecialchars($result['firmware']); ?></td></tr>
                        <tr><td>Seriennummer</td><td><?php echo htmlspecialchars($result['serial']); ?></td></tr>
                        <tr><td>Max. Benutzer</td><td><?php echo $result['users']; ?></td></tr>
                        <tr><td>Max. Aufzeichnungen</td><td><?php echo $result['records']; ?></td></tr>
                    </table>
                <?php elseif ($action === 'records'): ?>
                    <h2>Anwesenheitsaufzeichnungen</h2>
                    <p>Gesamt: <?php echo $result['total']; ?> | Neue: <?php echo $result['new']; ?></p>
                    <?php if (!empty($result['records'])): ?>
                        <table>
                            <tr><th>User-ID</th><th>Zeitstempel</th><th>Methode</th></tr>
                            <?php foreach ($result['records'] as $r): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['user']); ?></td>
                                    <td><?php echo htmlspecialchars($r['time']); ?></td>
                                    <td><?php echo htmlspecialchars($r['method']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php else: ?>
                        <p>Keine Aufzeichnungen vorhanden</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
