<?php
/**
 * Beispiel 3: Anwesenheitsaufzeichnungen
 * 
 * Zeigt wie man Aufzeichnungen herunterlädt und verarbeitet
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Anviz\SDK\Core\AnvizClient;

$host = $_ENV['ANVIZ_HOST'] ?? '192.168.1.100';
$port = (int)($_ENV['ANVIZ_PORT'] ?? 5010);
$deviceId = (int)($_ENV['ANVIZ_DEVICE_ID'] ?? 1);

try {
    $client = new AnvizClient($host, $port, $deviceId);
    $client->connect();

    echo "=== ANWESENHEITSAUFZEICHNUNGEN ===\n";
    echo str_repeat("=", 80) . "\n\n";

    // Info abrufen
    $info = $client->getRecordInfo();
    echo "Neue Aufzeichnungen: " . $info['newRecords'] . "\n\n";

    if ($info['newRecords'] === 0) {
        echo "Keine neuen Aufzeichnungen verfügbar.\n";
        $client->disconnect();
        exit(0);
    }

    // Aufzeichnungen herunterladen
    echo "Laden...\n";
    $records = $client->downloadRecords();

    echo "\nGefundene Datensätze: " . count($records) . "\n";
    echo str_repeat("-", 80) . "\n";

    // Header
    printf("%-5s | %-10s | %-20s | %-30s | %-8s\n", 
        "Nr.", "User-ID", "Zeitstempel", "Verifizierungsmethode", "Typ");
    echo str_repeat("-", 80) . "\n";

    // Daten
    foreach ($records as $i => $record) {
        printf("%-5d | %-10s | %-20s | %-30s | %-8d\n",
            $i + 1,
            $record->getUserId(),
            $record->getTimestamp()->format('Y-m-d H:i:s'),
            $record->getVerificationMethod(),
            $record->getRecordType()
        );
    }

    echo str_repeat("-", 80) . "\n\n";

    // In CSV exportieren (optional)
    $filename = __DIR__ . '/../exports/records_' . date('Y-m-d_H-i-s') . '.csv';
    @mkdir(dirname($filename), 0777, true);

    $fp = fopen($filename, 'w');
    fputcsv($fp, ['Nr.', 'User-ID', 'Zeitstempel', 'Methode', 'Typ']);

    foreach ($records as $i => $record) {
        fputcsv($fp, [
            $i + 1,
            $record->getUserId(),
            $record->getTimestamp()->format('Y-m-d H:i:s'),
            $record->getVerificationMethod(),
            $record->getRecordType()
        ]);
    }

    fclose($fp);
    echo "✓ Exportiert nach: $filename\n\n";

    // Nach Download löschen (optional)
    echo "Neue Aufzeichnungen löschen? (y/n): ";
    $handle = fopen("php://stdin", "r");
    $answer = trim(fgets($handle));

    if ($answer === 'y') {
        if ($client->clearNewRecords()) {
            echo "✓ Aufzeichnungen gelöscht\n";
        } else {
            echo "✗ Fehler beim Löschen\n";
        }
    }

    $client->disconnect();

} catch (Exception $e) {
    echo "✗ Fehler: " . $e->getMessage() . "\n";
    exit(1);
}
