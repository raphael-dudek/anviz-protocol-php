<?php
/**
 * Beispiel 4: Benutzerverwaltung
 * 
 * Zeigt Benutzer hinzufügen, anzeigen und löschen
 */

require_once __DIR__ . '/../vendor/autoload.php';

use Anviz\SDK\Core\AnvizClient;
use Anviz\SDK\Models\UserInfo;

$host = $_ENV['ANVIZ_HOST'] ?? '192.168.1.100';
$port = (int)($_ENV['ANVIZ_PORT'] ?? 5010);
$deviceId = (int)($_ENV['ANVIZ_DEVICE_ID'] ?? 1);

try {
    $client = new AnvizClient($host, $port, $deviceId);
    $client->connect();

    echo "=== BENUTZERVERWALTUNG ===\n";
    echo str_repeat("=", 80) . "\n\n";

    echo "Optionen:\n";
    echo "  1 - Benutzer auflisten\n";
    echo "  2 - Benutzer hinzufügen\n";
    echo "  3 - Benutzer löschen\n\n";

    echo "Wählen Sie eine Option (1-3): ";
    $handle = fopen("php://stdin", "r");
    $option = trim(fgets($handle));

    switch ($option) {
        case '1':
            // Benutzer auflisten
            echo "\nLade Benutzer...\n\n";
            $users = $client->downloadUsers(0, 0);

            echo "Gefundene Benutzer: " . count($users) . "\n";
            echo str_repeat("-", 80) . "\n";

            printf("%-10s | %-20s | %-15s | %-5s\n", 
                "User-ID", "Name", "Karten-ID", "Admin");
            echo str_repeat("-", 80) . "\n";

            foreach ($users as $user) {
                printf("%-10s | %-20s | %-15s | %-5s\n",
                    $user->getUserId(),
                    $user->getName(),
                    $user->getCardId(),
                    $user->isAdmin() ? 'Ja' : 'Nein'
                );
            }
            break;

        case '2':
            // Benutzer hinzufügen
            echo "\n=== Neuen Benutzer erstellen ===\n";

            echo "User-ID: ";
            $userId = (int)trim(fgets($handle));

            echo "Name (max. 20 Zeichen): ";
            $name = trim(fgets($handle));

            echo "Karten-ID (optional): ";
            $cardId = (int)trim(fgets($handle));

            $user = new UserInfo();
            $user->setUserId($userId);
            $user->setName(substr($name, 0, 20));
            if ($cardId > 0) {
                $user->setCardId($cardId);
            }
            $user->setDepartment(0);
            $user->setAdmin(false);

            if ($client->uploadUser($user)) {
                echo "\n✓ Benutzer erfolgreich erstellt\n";
            } else {
                echo "\n✗ Fehler beim Erstellen\n";
            }
            break;

        case '3':
            // Benutzer löschen
            echo "\n=== Benutzer löschen ===\n";

            echo "User-ID zum Löschen: ";
            $userId = (int)trim(fgets($handle));

            echo "Wirklich löschen? (y/n): ";
            $confirm = trim(fgets($handle));

            if ($confirm === 'y') {
                if ($client->deleteUser($userId)) {
                    echo "\n✓ Benutzer gelöscht\n";
                } else {
                    echo "\n✗ Fehler beim Löschen\n";
                }
            }
            break;

        default:
            echo "Ungültige Option\n";
    }

    $client->disconnect();

} catch (Exception $e) {
    echo "✗ Fehler: " . $e->getMessage() . "\n";
    exit(1);
}
