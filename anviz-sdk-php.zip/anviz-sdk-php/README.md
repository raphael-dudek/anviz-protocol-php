# Anviz SDK PHP

Vollständige PHP-Portierung des [MxLabs/Anviz](https://github.com/MxLabs/Anviz) C# SDK für die Kommunikation mit Anviz-Biometric-Geräten über TCP/IP.

## Features

- ✅ Vollständige TCP/IP-Kommunikation
- ✅ CRC16-Validierung nach Anviz-Protokoll
- ✅ Alle gängigen Anviz-Befehle implementiert
- ✅ Geräteinformationen abrufen
- ✅ Datum/Uhrzeit-Verwaltung
- ✅ Anwesenheitsaufzeichnungen herunterladen
- ✅ Benutzerverwaltung (Hinzufügen/Löschen/Abrufen)
- ✅ Netzwerkkonfiguration abrufen
- ✅ Docker-unterstützt
- ✅ Vollständig dokumentiert mit Beispielen

## Installation

### Lokale Installation

```bash
git clone https://github.com/yourusername/anviz-sdk-php.git
cd anviz-sdk-php
composer install
```

### Docker Installation

```bash
docker-compose up -d anviz-sdk
docker-compose exec anviz-sdk php examples/connect.php
```

## Schnellstart

```php
<?php
require_once 'vendor/autoload.php';

use Anviz\SDK\Core\AnvizClient;

// Client erstellen
$client = new AnvizClient('192.168.1.100', 5010, 1);
$client->connect();

// Geräteinformationen
$info = $client->getDeviceInfo();
echo "Modell: " . $client->getDeviceModel() . "\n";
echo "Firmware: " . $info->getFirmwareVersion() . "\n";

// Aufzeichnungen herunterladen
$records = $client->downloadRecords();
foreach ($records as $record) {
    echo sprintf("%s - %s\n",
        $record->getUserId(),
        $record->getTimestamp()->format('Y-m-d H:i:s')
    );
}

$client->disconnect();
```

## Projektstruktur

```
anviz-sdk-php/
├── src/
│   ├── Core/              # Kernkomponenten
│   │   ├── Message.php
│   │   ├── Request.php
│   │   ├── Response.php
│   │   └── AnvizClient.php
│   ├── Communication/     # Netzwerkkommunikation
│   │   └── TcpClient.php
│   ├── Models/            # Datenmodelle
│   │   ├── DeviceInfo.php
│   │   ├── UserInfo.php
│   │   ├── AttendanceRecord.php
│   │   └── NetworkConfig.php
│   └── Utils/             # Hilfsfunktionen
│       ├── CRC16.php
│       ├── BinaryHelper.php
│       └── Logger.php
├── examples/              # Verwendungsbeispiele
│   ├── 01_connect.php
│   ├── 02_device_info.php
│   ├── 03_records.php
│   └── 04_user_management.php
├── tests/                 # Unit Tests
├── docker-compose.yml
├── Dockerfile
├── composer.json
└── README.md
```

## Dokumentation

- [Installation Guide](docs/INSTALLATION.md)
- [API Reference](docs/API.md)
- [Protocol Details](docs/PROTOCOL.md)
- [Examples](examples/)

## Unterstützte Geräte

- TC550, TC500, OC500 Serie
- M7, M5, P7, P5 Serie
- FaceDeep 3/5/7 Serie
- W1, W2, C2 Serie
- Alle Anviz TCP/IP-Geräte

## Lizenz

MIT License

## Credits

- Original C# SDK: [MxLabs/Anviz](https://github.com/MxLabs/Anviz)
- Protokoll: Anviz Global Inc.
