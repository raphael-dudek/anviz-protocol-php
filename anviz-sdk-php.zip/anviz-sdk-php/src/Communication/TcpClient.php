<?php

namespace Anviz\SDK\Communication;

use Exception;

/**
 * TCP-Client für Netzwerkkommunikation
 */
class TcpClient
{
    private $host;
    private $port;
    private $timeout;
    private $socket;
    private $connected;

    public function __construct(string $host, int $port, int $timeout = 5)
    {
        $this->host = $host;
        $this->port = $port;
        $this->timeout = $timeout;
        $this->socket = null;
        $this->connected = false;
    }

    public function connect(): bool
    {
        if ($this->connected) return true;

        $this->socket = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

        if ($this->socket === false) {
            throw new Exception("Socket konnte nicht erstellt werden");
        }

        socket_set_option($this->socket, SOL_SOCKET, SO_RCVTIMEO, 
                         ['sec' => $this->timeout, 'usec' => 0]);
        socket_set_option($this->socket, SOL_SOCKET, SO_SNDTIMEO, 
                         ['sec' => $this->timeout, 'usec' => 0]);

        $result = @socket_connect($this->socket, $this->host, $this->port);

        if ($result === false) {
            socket_close($this->socket);
            throw new Exception("Verbindung zu {$this->host}:{$this->port} fehlgeschlagen");
        }

        $this->connected = true;
        return true;
    }

    public function send(string $data): int
    {
        if (!$this->connected) {
            throw new Exception("Nicht verbunden");
        }

        $length = strlen($data);
        $sent = @socket_write($this->socket, $data, $length);

        if ($sent === false) {
            throw new Exception("Senden fehlgeschlagen");
        }

        return $sent;
    }

    public function receive(int $maxLength = 4096): string
    {
        if (!$this->connected) {
            throw new Exception("Nicht verbunden");
        }

        $data = @socket_read($this->socket, $maxLength, PHP_BINARY_READ);

        if ($data === false) {
            return '';
        }

        return $data;
    }

    public function disconnect(): void
    {
        if ($this->socket !== null) {
            @socket_close($this->socket);
            $this->socket = null;
        }
        $this->connected = false;
    }

    public function isConnected(): bool
    {
        return $this->connected;
    }

    public function __destruct()
    {
        $this->disconnect();
    }
}
