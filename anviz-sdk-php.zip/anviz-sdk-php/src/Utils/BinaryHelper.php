<?php

namespace Anviz\SDK\Utils;

/**
 * Hilfsfunktionen für Binärdaten
 */
class BinaryHelper
{
    public static function readUInt16LE(array $data, int $offset): int
    {
        return $data[$offset] | ($data[$offset + 1] << 8);
    }

    public static function readUInt16BE(array $data, int $offset): int
    {
        return ($data[$offset] << 8) | $data[$offset + 1];
    }

    public static function readUInt32LE(array $data, int $offset): int
    {
        return $data[$offset] | ($data[$offset + 1] << 8)
             | ($data[$offset + 2] << 16) | ($data[$offset + 3] << 24);
    }

    public static function readUInt32BE(array $data, int $offset): int
    {
        return ($data[$offset] << 24) | ($data[$offset + 1] << 16)
             | ($data[$offset + 2] << 8) | $data[$offset + 3];
    }

    public static function writeUInt16LE(int $value): string
    {
        return chr($value & 0xFF) . chr(($value >> 8) & 0xFF);
    }

    public static function writeUInt16BE(int $value): string
    {
        return chr(($value >> 8) & 0xFF) . chr($value & 0xFF);
    }

    public static function writeUInt32LE(int $value): string
    {
        return chr($value & 0xFF) . chr(($value >> 8) & 0xFF)
             . chr(($value >> 16) & 0xFF) . chr(($value >> 24) & 0xFF);
    }

    public static function writeUInt32BE(int $value): string
    {
        return chr(($value >> 24) & 0xFF) . chr(($value >> 16) & 0xFF)
             . chr(($value >> 8) & 0xFF) . chr($value & 0xFF);
    }

    public static function readFixedString(array $data, int $offset, int $length): string
    {
        $str = '';
        for ($i = 0; $i < $length; $i++) {
            $byte = $data[$offset + $i] ?? 0;
            if ($byte === 0) break;
            $str .= chr($byte);
        }
        return $str;
    }

    public static function writeFixedString(string $str, int $length): string
    {
        $result = str_pad($str, $length, "\x00");
        return substr($result, 0, $length);
    }

    public static function bytesToHex(array $bytes): string
    {
        $hex = '';
        foreach ($bytes as $byte) {
            $hex .= sprintf('%02X ', $byte);
        }
        return trim($hex);
    }

    public static function stringToBytes(string $str): array
    {
        return array_values(unpack('C*', $str));
    }
}
