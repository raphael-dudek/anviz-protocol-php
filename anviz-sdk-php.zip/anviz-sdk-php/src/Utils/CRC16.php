<?php

namespace Anviz\SDK\Utils;

/**
 * CRC16 Checksum Calculator
 */
class CRC16
{
    private static $crcTable = null;

    private static function initTable(): void
    {
        if (self::$crcTable !== null) return;
        self::$crcTable = array_fill(0, 256, 0);

        for ($i = 0; $i < 256; $i++) {
            $crc = $i;
            for ($j = 0; $j < 8; $j++) {
                if ($crc & 1) {
                    $crc = ($crc >> 1) ^ 0xA001;
                } else {
                    $crc >>= 1;
                }
            }
            self::$crcTable[$i] = $crc & 0xFFFF;
        }
    }

    public static function compute(array $data, int $length): int
    {
        self::initTable();
        $crc = 0xFFFF;

        for ($i = 0; $i < $length; $i++) {
            $index = ($crc ^ $data[$i]) & 0xFF;
            $crc = (($crc >> 8) ^ self::$crcTable[$index]) & 0xFFFF;
        }

        return $crc & 0xFFFF;
    }

    public static function validate(array $data, int $length): bool
    {
        if ($length < 2) return false;
        $calculatedCrc = self::compute($data, $length - 2);
        $receivedCrc = $data[$length - 2] | ($data[$length - 1] << 8);
        return $calculatedCrc === $receivedCrc;
    }
}
