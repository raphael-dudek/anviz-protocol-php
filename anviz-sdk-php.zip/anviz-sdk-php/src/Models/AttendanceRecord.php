<?php

namespace Anviz\SDK\Models;

use Anviz\SDK\Utils\BinaryHelper;
use DateTime;

/**
 * Anwesenheitsaufzeichnungs-Modell
 */
class AttendanceRecord
{
    private $userId;
    private $timestamp;
    private $backupCode;
    private $recordType;
    private $workType;

    public function __construct()
    {
        $this->userId = 0;
        $this->timestamp = new DateTime();
        $this->backupCode = 0;
        $this->recordType = 0;
        $this->workType = 0;
    }

    public static function fromByteArray(array $data, int $offset = 0): self
    {
        $record = new self();

        $userIdStr = sprintf('%02X%02X%02X%02X%02X', 
            $data[$offset] ?? 0, $data[$offset+1] ?? 0, $data[$offset+2] ?? 0,
            $data[$offset+3] ?? 0, $data[$offset+4] ?? 0);
        $record->userId = (int)$userIdStr;
        $offset += 5;

        $timestamp = BinaryHelper::readUInt32LE($data, $offset);
        $record->timestamp = new DateTime('@' . $timestamp);
        $offset += 4;

        $record->backupCode = $data[$offset] ?? 0;
        $offset += 1;

        $record->recordType = $data[$offset] ?? 0;
        $offset += 1;

        $record->workType = $data[$offset] ?? 0;

        return $record;
    }

    public static function parseMultiple(array $data): array
    {
        $records = [];
        $recordSize = 12;
        $count = (int)(count($data) / $recordSize);

        for ($i = 0; $i < $count; $i++) {
            $offset = $i * $recordSize;
            if ($offset + $recordSize <= count($data)) {
                $records[] = self::fromByteArray($data, $offset);
            }
        }

        return $records;
    }

    public function getUserId(): int { return $this->userId; }
    public function getTimestamp(): DateTime { return $this->timestamp; }
    public function getBackupCode(): int { return $this->backupCode; }
    public function getRecordType(): int { return $this->recordType; }
    public function getWorkType(): int { return $this->workType; }

    public function getVerificationMethod(): string
    {
        $methods = [
            0 => 'Fingerprint', 1 => 'Password', 2 => 'Card',
            3 => 'Fingerprint+Password', 4 => 'Fingerprint+Card',
            5 => 'Password+Card', 10 => 'Face', 11 => 'Face+Fingerprint',
            15 => 'Palm'
        ];
        return $methods[$this->backupCode] ?? 'Unknown';
    }
}
