<?php

namespace Anviz\SDK\Models;

use Anviz\SDK\Utils\BinaryHelper;

/**
 * Geräteinformations-Modell
 */
class DeviceInfo
{
    private $deviceId;
    private $firmwareVersion;
    private $serialNumber;
    private $productName;
    private $userCapacity;
    private $fingerprintCapacity;
    private $cardCapacity;
    private $recordCapacity;

    public static function fromByteArray(array $data): self
    {
        $info = new self();

        $offset = 0;
        if (count($data) >= 48) {
            $info->deviceId = BinaryHelper::readUInt32LE($data, $offset);
            $offset += 4;

            $info->firmwareVersion = BinaryHelper::readFixedString($data, $offset, 16);
            $offset += 16;

            $info->serialNumber = BinaryHelper::readFixedString($data, $offset, 16);
            $offset += 16;

            $info->userCapacity = BinaryHelper::readUInt32LE($data, $offset);
            $offset += 4;

            $info->fingerprintCapacity = BinaryHelper::readUInt32LE($data, $offset);
            $offset += 4;

            $info->recordCapacity = BinaryHelper::readUInt32LE($data, $offset);
        }

        return $info;
    }

    public function getDeviceId(): int { return $this->deviceId ?? 0; }
    public function getFirmwareVersion(): string { return $this->firmwareVersion ?? ''; }
    public function getSerialNumber(): string { return $this->serialNumber ?? ''; }
    public function getProductName(): string { return $this->productName ?? ''; }
    public function getUserCapacity(): int { return $this->userCapacity ?? 0; }
    public function getFingerprintCapacity(): int { return $this->fingerprintCapacity ?? 0; }
    public function getCardCapacity(): int { return $this->cardCapacity ?? 0; }
    public function getRecordCapacity(): int { return $this->recordCapacity ?? 0; }
}
