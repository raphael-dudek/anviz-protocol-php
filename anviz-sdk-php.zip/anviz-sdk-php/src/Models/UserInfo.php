<?php

namespace Anviz\SDK\Models;

use Anviz\SDK\Utils\BinaryHelper;

/**
 * Benutzerinformations-Modell
 */
class UserInfo
{
    private $userId;
    private $name;
    private $password;
    private $cardId;
    private $department;
    private $admin;

    public function __construct()
    {
        $this->userId = 0;
        $this->name = '';
        $this->password = '';
        $this->cardId = 0;
        $this->department = 0;
        $this->admin = false;
    }

    public static function fromByteArray(array $data, int $offset = 0): self
    {
        $user = new self();

        $userIdStr = sprintf('%02X%02X%02X%02X%02X', 
            $data[$offset] ?? 0, $data[$offset+1] ?? 0, $data[$offset+2] ?? 0,
            $data[$offset+3] ?? 0, $data[$offset+4] ?? 0);
        $user->userId = (int)$userIdStr;
        $offset += 5;

        $user->name = BinaryHelper::readFixedString($data, $offset, 20);
        $offset += 20;

        $user->department = $data[$offset] ?? 0;
        $offset += 1;

        $user->admin = ($data[$offset] ?? 0) !== 0;

        return $user;
    }

    public static function parseMultiple(array $data): array
    {
        $users = [];
        $recordSize = 35;
        $count = (int)(count($data) / $recordSize);

        for ($i = 0; $i < $count; $i++) {
            $offset = $i * $recordSize;
            if ($offset + $recordSize <= count($data)) {
                $users[] = self::fromByteArray($data, $offset);
            }
        }

        return $users;
    }

    public function toByteString(): string
    {
        $data = '';

        $userIdStr = str_pad((string)$this->userId, 10, '0', STR_PAD_LEFT);
        for ($i = 0; $i < 10; $i += 2) {
            $data .= chr(hexdec(substr($userIdStr, $i, 2)));
        }

        $data .= BinaryHelper::writeFixedString($this->name, 20);
        $data .= chr($this->department);
        $data .= chr($this->admin ? 1 : 0);

        return $data;
    }

    public function getUserId(): int { return $this->userId; }
    public function setUserId(int $userId): void { $this->userId = $userId; }

    public function getName(): string { return $this->name; }
    public function setName(string $name): void { $this->name = $name; }

    public function getPassword(): string { return $this->password; }
    public function setPassword(string $password): void { $this->password = $password; }

    public function getCardId(): int { return $this->cardId; }
    public function setCardId(int $cardId): void { $this->cardId = $cardId; }

    public function getDepartment(): int { return $this->department; }
    public function setDepartment(int $department): void { $this->department = $department; }

    public function isAdmin(): bool { return $this->admin; }
    public function setAdmin(bool $admin): void { $this->admin = $admin; }
}
