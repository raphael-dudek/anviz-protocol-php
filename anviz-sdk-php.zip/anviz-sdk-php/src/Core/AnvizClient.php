<?php

namespace Anviz\SDK\Core;

use Anviz\SDK\Communication\TcpClient;
use Anviz\SDK\Models\DeviceInfo;
use Anviz\SDK\Models\UserInfo;
use Anviz\SDK\Models\AttendanceRecord;
use Anviz\SDK\Models\NetworkConfig;
use Anviz\SDK\Utils\BinaryHelper;
use Anviz\SDK\Utils\Logger;
use Exception;

/**
 * Hauptklasse für die Kommunikation mit Anviz-Geräten
 */
class AnvizClient
{
    // Befehlscodes
    const CMD_GET_INFO_1 = 0x30;
    const CMD_SET_INFO_1 = 0x31;
    const CMD_GET_INFO_2 = 0x32;
    const CMD_SET_INFO_2 = 0x33;
    const CMD_GET_DATETIME = 0x38;
    const CMD_SET_DATETIME = 0x39;
    const CMD_GET_NETWORK = 0x3A;
    const CMD_SET_NETWORK = 0x3B;
    const CMD_GET_RECORD_INFO = 0x3C;
    const CMD_DOWNLOAD_RECORDS = 0x40;
    const CMD_UPLOAD_RECORD = 0x41;
    const CMD_DOWNLOAD_USER = 0x42;
    const CMD_UPLOAD_USER = 0x43;
    const CMD_GET_DEVICE_ID = 0x46;
    const CMD_GET_MODEL = 0x48;
    const CMD_DELETE_USER = 0x4C;
    const CMD_CLEAR_RECORDS = 0x4E;
    const CMD_PING = 0x7F;

    private $host;
    private $port;
    private $deviceId;
    private $timeout;
    private $tcpClient;

    public function __construct(string $host, int $port = 5010, int $deviceId = 1, int $timeout = 5)
    {
        $this->host = $host;
        $this->port = $port;
        $this->deviceId = $deviceId;
        $this->timeout = $timeout;
        $this->tcpClient = new TcpClient($host, $port, $timeout);
    }

    public function connect(): bool
    {
        Logger::info("Verbinde zu {$this->host}:{$this->port}");
        return $this->tcpClient->connect();
    }

    public function disconnect(): void
    {
        Logger::info("Trenne Verbindung");
        $this->tcpClient->disconnect();
    }

    public function isConnected(): bool
    {
        return $this->tcpClient->isConnected();
    }

    private function sendCommand(int $command, string $data = ''): Response
    {
        Logger::debug("Sende Befehl 0x" . dechex($command));

        $request = new Request($this->deviceId, $command, $data);
        $requestData = $request->getPayloadString();

        $this->tcpClient->send($requestData);
        $responseData = $this->tcpClient->receive();

        if (empty($responseData)) {
            throw new Exception("Keine Antwort vom Gerät erhalten");
        }

        $response = new Response($responseData);

        if (!$response->isValid()) {
            throw new Exception("Ungültige CRC in Antwort");
        }

        if ($response->getRet() !== 0) {
            throw new Exception("Gerät gibt Fehler zurück: " . $response->getRet());
        }

        Logger::debug("Befehl erfolgreich abgeschlossen");
        return $response;
    }

    public function ping(): bool
    {
        try {
            $response = $this->sendCommand(self::CMD_PING);
            return $response->isSuccess();
        } catch (Exception $e) {
            Logger::warn("Ping fehlgeschlagen: " . $e->getMessage());
            return false;
        }
    }

    public function getDeviceInfo(): DeviceInfo
    {
        $response = $this->sendCommand(self::CMD_GET_INFO_1);
        return DeviceInfo::fromByteArray($response->getData());
    }

    public function getDateTime(): \DateTime
    {
        $response = $this->sendCommand(self::CMD_GET_DATETIME);
        $data = $response->getData();

        if (count($data) >= 6) {
            $year = 2000 + $data[0];
            $month = $data[1];
            $day = $data[2];
            $hour = $data[3];
            $minute = $data[4];
            $second = $data[5];

            return new \DateTime(sprintf('%04d-%02d-%02d %02d:%02d:%02d',
                $year, $month, $day, $hour, $minute, $second));
        }

        throw new Exception("Ungültiges Datumsformat");
    }

    public function setDateTime(\DateTime $dateTime): bool
    {
        $year = (int)$dateTime->format('y');
        $month = (int)$dateTime->format('m');
        $day = (int)$dateTime->format('d');
        $hour = (int)$dateTime->format('H');
        $minute = (int)$dateTime->format('i');
        $second = (int)$dateTime->format('s');

        $data = chr($year) . chr($month) . chr($day) 
              . chr($hour) . chr($minute) . chr($second);

        $response = $this->sendCommand(self::CMD_SET_DATETIME, $data);
        return $response->isSuccess();
    }

    public function getNetworkConfig(): NetworkConfig
    {
        $response = $this->sendCommand(self::CMD_GET_NETWORK);
        return NetworkConfig::fromByteArray($response->getData());
    }

    public function getRecordInfo(): array
    {
        $response = $this->sendCommand(self::CMD_GET_RECORD_INFO);
        $data = $response->getData();

        if (count($data) >= 12) {
            return [
                'totalRecords' => BinaryHelper::readUInt32LE($data, 0),
                'newRecords' => BinaryHelper::readUInt32LE($data, 4),
                'capacity' => BinaryHelper::readUInt32LE($data, 8)
            ];
        }

        return ['totalRecords' => 0, 'newRecords' => 0, 'capacity' => 0];
    }

    public function downloadRecords(int $count = 0): array
    {
        $info = $this->getRecordInfo();

        if ($count === 0 || $count > $info['newRecords']) {
            $count = $info['newRecords'];
        }

        if ($count === 0) {
            return [];
        }

        $data = BinaryHelper::writeUInt32LE($count);
        $response = $this->sendCommand(self::CMD_DOWNLOAD_RECORDS, $data);

        return AttendanceRecord::parseMultiple($response->getData());
    }

    public function downloadUsers(int $startIndex = 0, int $count = 0): array
    {
        $data = BinaryHelper::writeUInt32LE($startIndex) 
              . BinaryHelper::writeUInt32LE($count);

        $response = $this->sendCommand(self::CMD_DOWNLOAD_USER, $data);
        return UserInfo::parseMultiple($response->getData());
    }

    public function uploadUser(UserInfo $user): bool
    {
        $data = $user->toByteString();
        $response = $this->sendCommand(self::CMD_UPLOAD_USER, $data);
        return $response->isSuccess();
    }

    public function deleteUser(int $userId): bool
    {
        $data = BinaryHelper::writeUInt32LE($userId);
        $response = $this->sendCommand(self::CMD_DELETE_USER, $data);
        return $response->isSuccess();
    }

    public function clearNewRecords(): bool
    {
        $data = chr(0);
        $response = $this->sendCommand(self::CMD_CLEAR_RECORDS, $data);
        return $response->isSuccess();
    }

    public function clearAllRecords(): bool
    {
        $data = chr(1);
        $response = $this->sendCommand(self::CMD_CLEAR_RECORDS, $data);
        return $response->isSuccess();
    }

    public function getDeviceModel(): string
    {
        $response = $this->sendCommand(self::CMD_GET_MODEL);
        $data = $response->getData();

        return BinaryHelper::readFixedString($data, 0, min(50, count($data)));
    }
}
