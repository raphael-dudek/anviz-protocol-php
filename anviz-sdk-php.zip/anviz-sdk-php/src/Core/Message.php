<?php

namespace Anviz\SDK\Core;

use Anviz\SDK\Utils\CRC16;

/**
 * Basis-Nachrichtenklasse für Anviz-Protokoll
 * 
 * Nachrichtenformat:
 * [Preamble] [DeviceID] [Command] [RET] [Length] [Data] [CRC16]
 * 0xA5       4 bytes     1 byte    1 byte 2 bytes  N bytes 2 bytes
 */
abstract class Message
{
    const PREAMBLE = 0xA5;
    const HEADER_SIZE = 8;
    const CRC_SIZE = 2;

    protected $deviceId;
    protected $command;
    protected $payload;
    protected $responseCode;

    public function __construct(int $deviceId)
    {
        $this->deviceId = $deviceId;
        $this->payload = [];
    }

    protected function buildPayload(int $command, string $data): void
    {
        $this->responseCode = ($command + 0x80) & 0xFF;
        $dataLength = strlen($data);
        $payloadLength = 8 + $dataLength + 2;

        if ($command > 0x80) {
            $payloadLength += 1;
        }

        $payload = array_fill(0, $payloadLength, 0);
        $i = 0;

        $payload[$i++] = self::PREAMBLE;
        $payload[$i++] = ($this->deviceId >> 24) & 0xFF;
        $payload[$i++] = ($this->deviceId >> 16) & 0xFF;
        $payload[$i++] = ($this->deviceId >> 8) & 0xFF;
        $payload[$i++] = $this->deviceId & 0xFF;
        $payload[$i++] = $command & 0xFF;

        if ($command > 0x80) {
            $payload[$i++] = 0x00;
        }

        $payload[$i++] = ($dataLength >> 8) & 0xFF;
        $payload[$i++] = $dataLength & 0xFF;

        for ($j = 0; $j < $dataLength; $j++) {
            $payload[$i++] = ord($data[$j]);
        }

        $crc = CRC16::compute($payload, $payloadLength - 2);
        $payload[$i++] = $crc & 0xFF;
        $payload[$i++] = ($crc >> 8) & 0xFF;

        $this->payload = $payload;
    }

    public function getPayload(): array { return $this->payload; }
    public function getPayloadString(): string {
        $bytes = '';
        foreach ($this->payload as $byte) {
            $bytes .= chr($byte);
        }
        return $bytes;
    }
    public function getDeviceId(): int { return $this->deviceId; }
    public function getResponseCode(): int { return $this->responseCode; }
}
