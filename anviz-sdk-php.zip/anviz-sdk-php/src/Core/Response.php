<?php

namespace Anviz\SDK\Core;

use Anviz\SDK\Utils\CRC16;
use Exception;

/**
 * Response-Klasse für Anviz-Antworten
 */
class Response
{
    private $deviceId;
    private $command;
    private $ret;
    private $dataLength;
    private $data;
    private $crc;
    private $valid;

    public function __construct(string $rawData)
    {
        $bytes = array_values(unpack('C*', $rawData));
        $this->parse($bytes);
    }

    private function parse(array $bytes): void
    {
        $length = count($bytes);
        if ($length < 10) {
            throw new Exception("Response zu kurz: $length bytes");
        }

        if ($bytes[0] !== Message::PREAMBLE) {
            throw new Exception(sprintf("Ungültiges Preamble: 0x%02X", $bytes[0]));
        }

        $this->deviceId = ($bytes[1] << 24) | ($bytes[2] << 16) 
                        | ($bytes[3] << 8) | $bytes[4];
        $this->command = $bytes[5];
        $this->ret = $bytes[6];
        $this->dataLength = ($bytes[7] << 8) | $bytes[8];
        $this->data = array_slice($bytes, 9, $this->dataLength);

        $crcPos = 9 + $this->dataLength;
        if ($crcPos + 1 < $length) {
            $this->crc = $bytes[$crcPos] | ($bytes[$crcPos + 1] << 8);
            $this->valid = CRC16::validate($bytes, $crcPos + 2);
        } else {
            $this->valid = false;
        }
    }

    public function getDeviceId(): int { return $this->deviceId; }
    public function getCommand(): int { return $this->command; }
    public function getRet(): int { return $this->ret; }
    public function getData(): array { return $this->data; }
    public function getDataString(): string {
        $str = '';
        foreach ($this->data as $byte) {
            $str .= chr($byte);
        }
        return $str;
    }
    public function getDataLength(): int { return $this->dataLength; }
    public function isValid(): bool { return $this->valid; }
    public function isSuccess(): bool { return $this->valid && $this->ret === 0; }
}
